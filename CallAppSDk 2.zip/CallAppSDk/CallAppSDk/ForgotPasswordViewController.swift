//
//  ForgotPasswordViewController.swift
//  CallAppSDk
//
//  Created by Jitender SIngh on 11/26/23.
//

import UIKit

class ForgotPasswordViewController: UIViewController {
    
    
    
    @IBOutlet weak var msgLbl: UILabel!
    
    
    @IBOutlet weak var emailIP: UITextField!
    
    
    @IBOutlet weak var SendBtn: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        SendBtn.isEnabled=false
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onEmailEdit(_ sender: Any) {
        
        
        SendBtn.isEnabled=true
        
    }
    
    @IBAction func onSend(_ sender: Any) {
        guard let email = self.emailIP.text,  !email.isEmpty else{
            self.msgLbl.text = "Please enter the email"
            return
        }
        Task{
            do{
                try await AuthenticationManager.shared.resetPassword(email: email)
                self.performSegue(withIdentifier: "ReLogin", sender: self)
                self.SendBtn.isEnabled = false
            }catch {
                print("Error at Resetting password: \(error.localizedDescription)")
            }
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
