//
//  SIgnupViewController.swift
//  CallAppSDk
//
//  Created by Jitender SIngh on 11/26/23.
//

import UIKit
import Firebase
import CometChatUIKitSwift
import CometChatSDK

class SIgnupViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var NameOL: UITextField!
    
    @IBOutlet weak var CountryOL: UITextField!
    
    
    @IBOutlet weak var BirthdayOL: UITextField!
    
    @IBOutlet weak var msgOL: UILabel!
    

    
    
    
    @IBOutlet weak var emailOL: UITextField!
    
    
    @IBOutlet weak var passwordOL: UITextField!
    
    
    
    
    
    
    @IBOutlet weak var checkpasswordOL: UITextField!
    
    @IBOutlet weak var create: UIButton!
    
    private let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.emailOL.text = ""
        self.passwordOL.text = ""
        self.msgOL.text = ""
        self.create.isEnabled = true
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func onmathc(_ sender: Any) {
        
        /*guard let password = passwordOL.text, !(self.checkpasswordOL.text!).isEmpty, password == self.checkpasswordOL.text else{
            self.msgOL.text = "Password should match!"
            self.create.isEnabled = false
            return
        }
        self.msgOL.text = ""
        self.create.isEnabled = true*/
        
        
    }
    
    
    
    
    @IBAction func Oncreate(_ sender: Any) {
        guard !(self.NameOL.text!).isEmpty,  !(self.CountryOL.text!).isEmpty, !(self.BirthdayOL.text!).isEmpty else{
            self.msgOL.text = "Enter valid details"
            return
        }
        guard !(self.emailOL.text!).isEmpty else{
            self.msgOL.text = "Enter valid email"
            return
        }
        guard !(self.passwordOL.text!).isEmpty,  !(self.checkpasswordOL.text!).isEmpty else{
            self.msgOL.text = "Enter valid password"
            return
        }
        Task {
            do{
                let authResult = try await AuthenticationManager.shared.createUser(email: self.emailOL.text!, password: self.passwordOL.text!)
                let userData: [String: Any] = [
                    "name": self.NameOL.text ?? "",
                    "birthday": self.BirthdayOL.text ?? "",
                    "country": self.CountryOL.text ?? ""
                ]
                self.db.collection("users").document(authResult.uid).setData(userData) { error in
                    if let error = error {
                        print("Error writing user data to Firestore: \(error.localizedDescription)")
                    } else {
                        print("User registered successfully with additional data!")
                        self.performSegue(withIdentifier: "ReloginSegue", sender: self)
                    }
                }
                let uid = authResult.uid
                let name = self.NameOL.text!
                
                let user = User(uid: uid, name: name)
                    CometChatUIKit.create(user: user) { result in
                            switch result {
                            case .success(_):
                                debugPrint("User created successfully \(String(describing: user.name))")
                              break
                            case .onError(let error):
                                debugPrint("Creating new user failed with exception: \(error.errorDescription)")
                              break
                            @unknown default:
                                break
                            }
                      }
                
                
            } catch {
                self.msgOL.text = error.localizedDescription
            }
        }
    }
    
    
    
    
}
